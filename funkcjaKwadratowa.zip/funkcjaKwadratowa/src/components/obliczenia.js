import { useState } from "react";

function Obliczenia(params) {
    const [a, setA] = useState(0);
    const [b, setB] = useState(0);
    const [c, setC] = useState(0);
    const [delta, setDelta] = useState(0);
    const [invalidValue, setInvalidValue] = useState('');

    const handlerChangeWynikDelta = (e) => {
        setDelta(b * b - 4*a * c);
    };

    const validation = (e) => {
        if (e===0 || e===null) {
            setInvalidValue('Nieprawidłowo wpisane wartości!!!');
        }
        else{setInvalidValue('');}
    }
    
    return(
        <div className="obliczenia">
            <div className="liczenie">
                <h3>Przykladowe obliczenia:</h3>
                <div className="zmienne">
                    {invalidValue}
                    <label htmlFor="a">Proszę podać a: </label>
                    <input 
                        id="a"
                        name="a"
                        type="number"
                        value={a}
                        onChange={(e) => setA(e.target.value) }
                        onBlur={(e) => validation(e)}/><br/>

                    <label htmlFor="b">Proszę podać b: </label>
                    <input 
                        id="b"
                        name="b"
                        type="number"
                        value={b}
                        onChange={(e) => setB(e.target.value)}
                        onBlur={(e) => validation(e)}/><br/>

                    <label htmlFor="c">Proszę podać c: </label>
                    <input 
                        id="c"
                        name="c"
                        type="number"
                        value={c}
                        onChange={(e) => setC(e.target.value)}
                        onBlur={(e) => validation(e)}/><br/><br/>
                    <hr/>
                </div>
                <div className="rownanie">
                    <h4>Równanie o postaci:</h4><br/>
                    <p>{a}x²+{b}x+{c}=0</p><br/>
                    <button onClick={() => handlerChangeWynikDelta()}>Oblicz</button><br/>
                    <p>Delta = {delta}</p>
                </div>
            </div>
            <div className="grafika">
                <h3>Interpretacja graficzna:</h3>
            </div>
        </div>
    )
}
export default Obliczenia; 