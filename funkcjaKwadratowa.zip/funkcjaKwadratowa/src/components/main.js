import Informacja from "./informacja";
import Obliczenia from "./obliczenia";

function Main(params) {
    return(
        <div className="main">
            <Informacja />

            <Obliczenia />
        </div>
    )
}
export default Main;