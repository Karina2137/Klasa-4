function Footer(params) {
    return(
        <div className="footer">
            <h4>Pomyślnego rozwiązywania równań kwadratowych</h4>
        </div>
    )
}
export default Footer;