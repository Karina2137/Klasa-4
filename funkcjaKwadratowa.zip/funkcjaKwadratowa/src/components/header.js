function Header(params) {
    return(
        <div className="header">
            <h1>Witamy na stronie: Matematyka dla każdego</h1>
            <h3>Pomożemy zrozymieć i rozwiązać: Równania Kwadratowe</h3>
            <hr/>
        </div>
    )
}
export default Header;