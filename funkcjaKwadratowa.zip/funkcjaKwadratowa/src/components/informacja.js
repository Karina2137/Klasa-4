function Informacja(params) {
    return(
        <div className="informacja">
            <h4>Postać ogólna:</h4>
            <div className="postacogolna">
                <p>ax²+bx+c</p>
                <br/>
                <p>wyroznik równania kwadratowego</p>
            </div>
            <div className="delta">
                <p>delta = b²-4ac</p>
                <ul>
                    <li>jeżeli delta {">"} 0 to równanie ma 2 rozwiązania:<br/> x1={"(-b*sqrt(delta))/2a"}<br/>x2={"(-b*sqrt(delta))/2a"}</li>
                    <li>jeżeli delta = 0 to równanie ma 1 rozwiązanie:<br/> x={"(-b)/2a"}</li>
                    <li>jeżeli delta {"<"} 0 to równanie nie ma rozwiązań</li>
                </ul>
                <hr/>
            </div>
        </div>
    )
}
export default Informacja;