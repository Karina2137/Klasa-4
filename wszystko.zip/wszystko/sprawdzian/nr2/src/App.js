import './App.css';
import kwiat from "./kwiat.png";
import drzewo from "./drzewo.png";
const rosliny =[
  {"lp":"1", "roslina":"Kwiaty", "rodzaj":"Polne", "przyklady":[
    {"id":"0", "nazwa":"mak"},
    {"id":"1", "nazwa":"rumianek"}
  ], "obraz":kwiat},
  {"lp":"2", "roslina":"Drzewa", "rodzaj":"Liściaste", "przyklady":[
    {"id":"0", "nazwa":"dąb"},
    {"id":"1", "nazwa":"buk"}
  ], "obraz":drzewo}
]

function App() {
  return (
    <div className="App">
      <h2>Moje Rośliny</h2>
      <table>
        <thead>
          <tr>
          <th>Lp</th>
          <th>Roślina</th>
          <th>Rodzaj</th>
          <th>Obrazek</th>
        </tr>
        </thead>
        <tbody>
          {rosliny.map((item, index)=>(
            <tr key={index}>
              <td>{item.lp}</td>
              <td>{item.roslina}</td>
              <td>{item.rodzaj} {item.przyklady.map((itemY,indexY)=>(
                <ul>
                  <li key={indexY}>{itemY.nazwa}</li>
                </ul>
              ))}</td>
              
              <td><img src={item.obraz}></img></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
