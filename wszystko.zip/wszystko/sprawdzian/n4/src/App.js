import Kwiaty from "./Kwiaty";

function App() {
  return (
    <div className="App">
      <h1>Salon Kwiatowy</h1>
      <Kwiaty />

    </div>
  );
}

export default App;
