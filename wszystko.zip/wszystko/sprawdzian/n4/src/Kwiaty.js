import './App.css';
import czerwone from "./kwiaty/czerwony.png"
import niebieskie from "./kwiaty/niebieskie.png"
import zolte from "./kwiaty/zolte.png"
import fioletowe from "./kwiaty/fioletowe.png"
import { useState } from "react";

function Kwiaty(params) {
    
    const [kwiaty, setKwiaty] = useState([
      {id: 1, kolor: "czerwone", il_rano: 3, il_wieczorem: 3, zdjecie: czerwone },
      {id: 2, kolor: "niebieskie", il_rano: 7, il_wieczorem: 7, zdjecie: niebieskie }
    ]);
    
    const wszystkieKwiaty =[
      {id: 1, kolor: "czerwone", il_rano: 3, il_wieczorem: 3, zdjecie: czerwone },
      {id: 2, kolor: "niebieskie", il_rano: 7, il_wieczorem: 7, zdjecie: niebieskie }
    ];
    
    const przyjmij = () => {
        const nowe = [
            {id: 3, kolor: "zółte", il_rano: 2, il_wieczorem: 2, zdjecie: zolte },
            {id: 4, kolor: "fioletowe", il_rano: 4, il_wieczorem: 4, zdjecie: fioletowe }
        ]
        setKwiaty(...kwiaty, ...nowe);
    };
    const sprzedaj = (id)=>{
      setKwiaty(...kwiaty, kwiaty.il_wieczorem-1);
    }
    const kup = (id)=>{
      var ilosc = prompt("Ilość przyjmowanych kwiatów: ")
      if (!isNaN(ilosc && ilosc>0)) {
        setKwiaty(...kwiaty, kwiaty.il_rano+ilosc);
      }
    }

    const usun = () =>{
      setKwiaty(...wszystkieKwiaty);
    }
return(
    <div className='sklep'>
      <div className='kwiat'>
        {kwiaty.map((item) => (
            <div key={item.id}>
                <h2>Polecamy: kwiaty {item.kolor}</h2>
                <img src={item.zdjecie} alt={item.kolor}></img>
                <p>Ilość rano: {item.il_rano}</p>
                <p>Ilość wieczorem: {item.il_wieczorem}</p>
            </div>
        ))}
      </div>
        <div className='buttons'>
          <button onClick={()=>sprzedaj(kwiaty.id=1)}>Sprzedaj</button>
          <button onClick={()=>kup(kwiaty.id=1)}>Kup</button>
          <button onClick={przyjmij}>Przyjmij</button>
          <button onClick={usun}>Usuń</button>
        </div>
    </div>
)}
export default Kwiaty;