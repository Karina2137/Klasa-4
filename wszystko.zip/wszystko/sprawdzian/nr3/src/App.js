import './App.css';
import MenuNapoje from './components/menu/MenuNapoje';
import MenuCiasta from './components/menu/MenuCiasta';
import Footer from './components/footer/Footer';
import Header from './components/header/Header';

function App() {
  return (
    <div className="App">
      <div className='naglowek'>
        <Header />
      </div>
      <div className='napoje'>
        <MenuNapoje />
      </div>
      <div className='ciasta'>
        <MenuCiasta />
      </div>
      <div className='stopka'>
        <Footer />
      </div>
    </div>
  );
}

export default App;
