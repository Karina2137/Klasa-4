import logo from './logo.png';
function Header() {
    return(
        <div>
            <h2>Witamy w naszej kawiarni</h2>
            <img width="200px" src={logo} alt="logo"></img>
        </div>
    )
}
export default Header;