import { Component } from "react";

class MenuCiasta extends Component{
    constructor(props){
        super(props);
        this.state = {
            ciasta: [
                {id: 1, nazwa: "Szarlotka"},
                {id: 2, nazwa: "Sernik"},
                {id: 3, nazwa: "Dzożdżówka"},
            ]
        };
    }
    render(){
        return(
            <div>
                <h4>Menu: ciasta</h4>
                {this.state.ciasta.map((item)=>(
                    <ol>
                        <p>{item.id}. {item.nazwa}</p>
                    </ol>
                ))}
            </div>
        )
    }
}
export default MenuCiasta;