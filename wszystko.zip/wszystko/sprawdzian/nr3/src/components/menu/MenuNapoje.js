import { Component } from "react";

class MenuNapoje extends Component{
    constructor(props){
        super(props);
        this.state = {
            napoje: [
                {id: 1, nazwa: "Herbata zielona"},
                {id: 2, nazwa: "Kawa czarna"},
                {id: 3, nazwa: "Kawa z mlekiem"},
            ]
        };
    }
    render(){
        return(
            <div>
                <h4>Menu: napoje</h4>
                {this.state.napoje.map((item)=>(
                    <ol>
                        <p>{item.id}. {item.nazwa}</p>
                    </ol>
                ))}
            </div>
        )
    }
}
export default MenuNapoje;