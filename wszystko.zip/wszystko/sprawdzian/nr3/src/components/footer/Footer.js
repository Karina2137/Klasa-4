function Footer() {
    return(
        <h5>Codziennie od 9:00 do 15:00</h5>
    )
}
export default Footer;