import kwadrat from "./kwadrat.png";
import './App.css';

function Pole() {
  let a = prompt("Podaj dlugość boku: ")
  a = parseInt(a);
  if (a>0 && a!=NaN) {
    let pole = a*a
    return <p className="wynikpola">Pole kwadratu o bokach długości {a} jest równe: {pole}</p>;}
    else{return <p className="wynikpola">Długość boku musi być liczbą, dodatnią i nie zerem</p>}
}

function App() {
  return (
    <div className="App">
      <img src={kwadrat} alt="kwadrat"/>
      <h2>Witaj w świecie geometrii</h2>
      <Pole />
    </div>
  );
}

export default App;
