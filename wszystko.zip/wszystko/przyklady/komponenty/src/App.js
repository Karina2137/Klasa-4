import './App.css';
import Book from './Book';

function App() {
  return (
    <Book />
  );
}

export default App;
