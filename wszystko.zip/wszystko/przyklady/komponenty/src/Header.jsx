function Header(props) {
    return(
        <h1>Witamy w bibliotece {props.nazwa} w {props.miasto}</h1>
    );
}

export default Header;	