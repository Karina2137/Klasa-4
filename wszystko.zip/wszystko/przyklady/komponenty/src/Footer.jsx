import Data from "./Data";

function Footer(){
    return (
        <h5>Dzisiaj jest {<Data />}</h5>
    )
}

export default Footer;