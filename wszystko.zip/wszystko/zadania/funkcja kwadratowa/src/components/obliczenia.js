function Obliczenia(params) {
    return(
        <div className="obliczenia">
            <div className="liczenie">
                <h3>Przykladowe obliczenia:</h3>
            </div>
            <div className="grafika">
                <h3>Interpretacja graficzna:</h3>
            </div>
        </div>
    )
}
export default Obliczenia;