import './App.css';

function objentoscSzescian(r) {
  return r*r*r;
}
function poleSzescian(r) {
  return r*r*6;
}
function objentoscProstopad(a, b, c) {
  return a*b*c;
}
function poleProstopad(a, b, c) {
  return 2*a*b+2*a*c+2*c*b;
}
function objentoscKuli(r) {
  return (4/3)*Math.PI*r*r*r;
}
function poleKuli(r) {
  return 4*Math.PI*r*r;
}
const bryly = [
{"id":0,"bryla":"Sześcian","ilustracja":"/ilust/szescian.png",
  "wzory":[
    {"id":0,"objentosc":"V=a^3"},
    {"id":1,"pole":"P=6a^2"}
  ],
  "przyklady":[
    {"id":0,"wymiar":"2"}
  ],
  "wynikiobj":objentoscSzescian(2),
  "wynikpole":poleSzescian(2)
},
{"id":1,"bryla":"Prostopadłościan", "ilustracja":"/ilust/prostopad.png",
 "wzory":[
    {"id":0,"objentosc":"V=a*b*c"},
    {"id":1,"pole":"P=2ab+2ac+2cb"}
 ],
 "przyklady":[
    {"id":0,"wymiar":"3"},
    {"id":1,"wymiar":"4"},
    {"id":2,"wymiar":"5"}
 ],
 "wynikiobj":objentoscProstopad(3,4,5),
 "wynikpole":poleProstopad(3,4,5)
},
{"id":2,"bryla":"Kula", "ilustracja":"/ilust/kula.png",
 "wzory":[
    {"id":0,"objentosc":"V=4/3*pi*r^3"},
    {"id":1,"pole":"P=4*pi*r^2"}
 ],
 "przyklady":[
    {"id":0,"wymiar":"4"}
  ],
  "wynikiobj":objentoscKuli(4),
  "wynikpole":poleKuli(4)
}
];

function App() {
  return (
    <div className="App">
      <h2>Bryły</h2>
      <table className='tabela' cellpadding="0" cellspacing="0">
        <tr>
          <th>BRYŁA</th>
          <th>ILUSTRACJA</th>
          <th>WZORY</th>
          <th>PRZYKŁAD</th>
          
        </tr>
        {bryly.map((item,index)=>(
          <tr key ={item.id}>
            <td>{item.bryla}</td>
            <td> <img src={item.ilustracja} alt={item.bryla}/></td>
            <td>
              {item.wzory.map((itemW,indexW)=>(
                  <p key={itemW.id}>{item.wzory[indexW].objentosc} {item.wzory[indexW].pole}</p>
              ))}
            </td>
            <td>
              <ul>
                {item.przyklady.map((itemY,indexY)=>(
                  <li key={itemY.id}> wartość{itemY.id+1}: {item.przyklady[indexY].wymiar} <br/></li>
                ))}
              </ul>
              <p key={item.id}> Objentosc: {item.wynikiobj}</p>
              <p key={item.id}> Pole: {item.wynikpole}</p>
            </td>
          </tr>
        ))}
      </table>
    </div>
  );
}

export default App;
