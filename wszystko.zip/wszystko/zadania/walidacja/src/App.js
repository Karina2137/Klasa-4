import './App.css';
import Age from './Walidacja';

function App() {
  return (
    <div className="App">
      <Age wiek={23} miesiac="10"/>
    </div>
  );
}

export default App;
