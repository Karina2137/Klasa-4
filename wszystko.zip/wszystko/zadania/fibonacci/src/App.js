import fibo from './fibonacci.jpg';
import './App.css';

function CgFibonacciego() {
  let n = prompt("Podaj ilość elementów (więcej niż 2): ")
  let a = 1
  let b = 1
  let iloczyn = a*b
  let dzialania = ""
  let kolejny = 0
  dzialania += "1*1"
  for (let i = 0; i < n-2; i++) {
    kolejny = a+b 
    dzialania+="*"+kolejny
    iloczyn*=kolejny
    a=b
    b=kolejny
  }
  dzialania= dzialania+"="+iloczyn
  return <p>Iloczyn {n} pierwszych liczb ciągu Fibonacciego: {dzialania}</p>
}

function App() {
  return (
    <div className='glowny'>
      <h2 className='naglowek'>Obliczanie iloczynu pierwszych liczb ciągu Fibonacciego</h2>
      <img className='obraz' src={fibo} alt="Fibonacci"/>
      <div className='wynik'>
        <h3 className='ciag'>Ciąg Fibonacciego</h3>
        <CgFibonacciego />
      </div>
    </div>
  ); 
}

export default App;