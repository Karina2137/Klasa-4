import { render } from "@testing-library/react";
import React, { Component } from "react";
class Licznik extends Component{
    constructor(props){
        super(props);
        this.state = {
            licznik : 0
        };
        this.zmniejsz = this.zmniejsz.bind(this);
        this.zwieksz = this.zwieksz.bind(this);
        this.czysc = this.czysc.bind(this);
    }
    zwieksz(){
        this.setState((prevState)=> ({
            licznik: prevState.licznik+1})
        );
    }
    zmniejsz(){
        this.setState((prevState)=> ({
            licznik: prevState.licznik-1})
        );
    }
    czysc() {
        this.setState({
            licznik: 0
        });
    }
render(){
    return(
        <div>
            <br/>
            Stan licznika: {this.state.licznik}<br></br>
            <button onClick={this.zwieksz}> Zwiększ o 1</button> <br></br>
            <button onClick={this.zmniejsz}> Zmniejsz o 1</button> <br></br>
            <button onClick={this.czysc}> Zeruj</button>
        </div>
    );
}
}

export default Licznik;