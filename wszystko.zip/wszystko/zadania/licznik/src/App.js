
import './App.css';
import Licznik from "./Counter.js"

function App() {
  return (
    <div className="App">
      <Licznik />
    </div>
  );
}

export default App;
