import { useState } from "react";


function Content(props) {
    const [obuwie, setObuwie] = useState([
        {id: 1, typ: "zimowe", zdjecie: {}, rodzaj: "", stan_magazynu: 13},
        {id: 2, typ: "zimowe", zdjecie: {}, rodzaj: "", stan_magazynu: 0},
        {id: 3, typ: "letnie", zdjecie: {}, rodzaj: "", stan_magazynu: 3},
        {id: 4, typ: "letnie", zdjecie: {}, rodzaj: "", stan_magazynu: 5},
        {id: 5, typ: "letnie", zdjecie: {}, rodzaj: "", stan_magazynu: 0},
        {id: 6, typ: "letnie", zdjecie: {}, rodzaj: "", stan_magazynu: 10}
    ])
    
    const wyswLetnie =()=>{
        const letnie = obuwie.filter(buty => buty.typ === "letnie");
        setObuwie(letnie);
    }
    const wyswZimowe=()=>{
        const zimowe = obuwie.filter(buty => buty.typ === "zimowe");
        setObuwie(zimowe);
    }
    const sprzedaz =(id)=>{
        setObuwie(obuwie.map(item=>item.id === id && item.stan_magazynu>0
            ? {...item, stan_magazynu: item.stan_magazynu-1}
            :item
        ))}

    const ustaw =(id)=>{
        const ilosc = parseInt(prompt("Podaj ilość przyjętych par: "))
        if (ilosc>0 && !isNaN(ilosc)) {
            setObuwie(obuwie.map(item=>item.id === id
            ? {...item, stan_magazynu: item.stan_magazynu+ilosc}
            :item
        ))}}

    return(
        <div className="all">
            <div className="headbuttons">
                <button onClick={()=>wyswLetnie()}>Więcej ofert obuwia letniego</button>
                <button onClick={()=>wyswZimowe()}>Więcej ofert zimowego letniego</button>
                <button onClick={""}>Usuń wyprzedane obuwie</button>
            </div>
            <h3>Nasze Rekomendacje:</h3>
            <div className="offer">
                {obuwie.map((item)=>(
                    <ol>
                        <img src={item.zdjecie} alt={item.rodzaj}></img>
                        <div className="description"> 
                            <h4>Rodzaj: {item.rodzaj}</h4>
                            <p>Stan magazynu: {item.stan_magazynu}</p>
                            <div className="zakup">
                                <button onClick={() => sprzedaz(item.id)}>Zakup parę</button>
                                <button onClick={() => ustaw(item.id)}>Przyjęcie pary</button>
                        </div>
                        </div>
                        
                    </ol>
                    
                ))}
            </div>
        </div>
    );
}
export default Content;