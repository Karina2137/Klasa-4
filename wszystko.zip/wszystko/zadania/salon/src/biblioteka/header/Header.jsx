import logo from "./logo.jpg"
function Header(props) {
    return(
        <header>
            <h1>Witamy na stronie księgarni: {props.nazwa}</h1>
            <img className="logo" src={logo} alt="logo"/>
        </header>
        
    );
}

export default Header;	