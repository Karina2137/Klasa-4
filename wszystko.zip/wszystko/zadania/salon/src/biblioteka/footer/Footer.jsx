function Footer(){
    return (
        <h5>Zapraszamy codziennie od 9:00 do 16:00 </h5>
    )
}

export default Footer;