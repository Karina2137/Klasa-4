import React, {Component} from "react";
import dom from "../main/stare/dom.png";
import asasin from "../main/stare/asasin.png";
import metro from "../main/stare/metro.png";

class BookOld extends Component {
    constructor(props) {
        super(props);
        this.state = {
            book: [
                {id: 0, title: "Dom soli i łez", zdjecie: dom},
                {id: 1, title: "Asasins Creed Renesans", zdjecie: asasin},
                {id: 2, title: "Metro 2034", zdjecie: metro}
            ]
        };
    }

    render(){
        return(
            <div className="App">
                <h2>Bestsellerowe UŻYWANE książki:</h2>
                {this.state.book.map((item,index)=>(
                    <ol>
                        <h1>Tytul: {item.title}</h1>
                        <h4>Zdjęcie:</h4>
                        <img src={item.zdjecie} alt="zdjęcie"/>
                    </ol>
                ))}
            </div>
        );
    }
}

export default BookOld;