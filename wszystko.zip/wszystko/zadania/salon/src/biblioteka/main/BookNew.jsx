import React, {Component} from "react";
import fourthwing from "../main/nowe/wing.jpg";
import ksiezyc from "../main/nowe/ksiezyc.jpg";
import powerless from "../main/nowe/powerless.jpg";

class BookNew extends Component {
    constructor(props) {
        super(props);
        this.state = {
            book: [
                {id: 0, title: "Fourth Wing", zdjecie: fourthwing},
                {id: 1, title: "Kiedy wykluł sę księżyc", zdjecie: ksiezyc},
                {id: 2, title: "Bezsilna", zdjecie: powerless}
            ]
        };
    }

    render(){
        return(
            <div className="App">
                <h2>Bestsellerowe NOWE książki:</h2>
                {this.state.book.map((item,index)=>(
                    <ol>
                        <h1>Tytul: {item.title}</h1>
                        <h4>Zdjęcie:</h4>
                        <img src={item.zdjecie} alt="zdjecie"/>
                    </ol>
                ))}
            </div>
        );
    }
}

export default BookNew;