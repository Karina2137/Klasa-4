import React, {Component} from "react";
import Header from "./biblioteka/header/Header";
import Footer from "./biblioteka/footer/Footer";
import BookNew from "./biblioteka/main/BookNew";
import BookOld from "./biblioteka/main/BookOld";

class Book extends Component {
    
    render(){
        return(
            <div className="App">
                <div className="header">
                    <Header nazwa='Green Pages'/>
                </div>
                <div className="nowe">
                    <BookNew />
                </div>
                <div className="uzywane">
                    <BookOld />
                </div>
                <div className="footer">
                    <Footer />
                </div>
                
                
            </div>
        );
    }
}

export default Book;