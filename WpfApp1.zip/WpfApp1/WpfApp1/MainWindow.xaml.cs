﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Koszyk koszyk;
        public int CurrentProduct;
        public MainWindow()
        {
            koszyk = new Koszyk();
            InitializeComponent();
            InitializaProductViever();
            CurrentProduct = 0;
        }
        public void InitializaProductViever()
        {
            Dane.Text = koszyk.Produkty.ElementAt(CurrentProduct).Nazwa;
            Cena.Text = koszyk.Produkty.ElementAt(CurrentProduct).Cena.ToString();
            if (CurrentProduct == 0)
            {
                bPrev.IsEnabled = false;
            }
            if (CurrentProduct == koszyk.Produkty.Count-1)
            {
                bNext.IsEnabled = false;
            }
        }

        private void bPrev_Click(object sender, RoutedEventArgs e)
        {
            CurrentProduct -= 1;
        }

        private void bNext_Click(object sender, RoutedEventArgs e)
        {
            CurrentProduct += 1;
        }
    }
}