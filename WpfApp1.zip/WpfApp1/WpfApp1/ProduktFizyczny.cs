﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    internal class ProduktFizyczny : Produkt
    {
        public ProduktFizyczny(string nazwa, int cena) : base(nazwa, cena)
        {
        }
    }

    internal class ProduktFizyczny2 : Produkt
    {
        public ProduktFizyczny2(string nazwa, int cena) : base(nazwa, cena)
        {
        }
    }
}
