function Header(props) {
    return(
        <h2>Witamy na stronie firmy</h2>
    );
}
export default Header;